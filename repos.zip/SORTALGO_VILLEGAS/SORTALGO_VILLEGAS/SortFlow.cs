﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Channels;

namespace SORTALGO_VILLEGAS
{
    //Contains the overall flow of the program
    class ItoPoAngFlowNgProject
    {

    public void Start()
    {
        //TITLE (FOR FORMALITY)
        Console.ForegroundColor = ConsoleColor.Black;
        Console.BackgroundColor = ConsoleColor.Cyan;
        Console.WriteLine("********************** SORTING SYSTEM BY VILLEGAS **********************");
        Console.BackgroundColor = ConsoleColor.Black;    

        //Getting the user input array elements
        int[] numbers = ElementByUser();
        int[] originalArray = new int[numbers.Length];
        Array.Copy(numbers, originalArray, numbers.Length);

        while (true)
        {
            //Displays the option for sorting algorithms
            Console.WriteLine("\nChoose a sorting algorithm of your choice!");
            Console.WriteLine("        (Enter a number from 0-6)\n");
            Console.WriteLine("1) Bubble Sort");
            Console.WriteLine("2) Selection Sort");
            Console.WriteLine("3) Merge Sort");
            Console.WriteLine("4) Insertion Sort");
            Console.WriteLine("5) Quick Sort");
            Console.WriteLine("6) Heap Sort");
            Console.WriteLine("0) Exit");

            //Getting the chosen algorithm of the user
            int choice = GetUserChoice(0, 6);

            if (choice == 0)
            {
                //Exits the program
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\nThat is all! Thank you for using my Sorting System! Adios!\n" +
                    "                  MADE BY VILLEGAS\n");
                Console.ResetColor();
                break;
            }
            else if (choice == 1)
            {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"\nSorting using Bubble Sort:");
                    Console.WriteLine("");
            }
            else if (choice == 2)
            {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"\nSorting using Selection Sort:");
                    Console.WriteLine("");
            }
            else if (choice == 3)
            {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"\nSorting using Merge Sort:");
                    Console.WriteLine("");
            }
            else if (choice == 4)
            {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"\nSorting using Insertion Sort:");
                    Console.WriteLine("");
            }
            else if (choice == 5)
            {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"\nSorting using Quick Sort:");
                    Console.WriteLine("");
            }
            else if (choice == 6)
            {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"\nSorting using Heap Sort:");
                    Console.WriteLine("");
            }


            // Sorting the array based on user's choice 
            int passes = SortPass(numbers, (SortChoices)choice);

            //Displays the total amount of passes for each sorting algorithm
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.Write("Total Passes: "); 
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($"{passes}\n");
            
            //Prompt when the user is asked if they want to try another sorting algorithm
            if (!AskUserToTryAgain())
            {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\nThat is all! Thank you for using my Sorting System! Adios!\n" +
                    "                  MADE BY VILLEGAS\n");
                    Console.ResetColor();
                    break;
            }

        }
    }

    static int[] ElementByUser()
    {
            //Prompting the user to enter numbers separated by spaces
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.Write("\nEnter numbers separated by spaces (Maximum of 10 numbers): ");
            Console.ForegroundColor = ConsoleColor.White;
            //Reading the user input
            string userInput = Console.ReadLine();

            //Checking if the user input is null or empty
            if (string.IsNullOrWhiteSpace(userInput))
            {
                //Informing the user that the input should not be blank and ask for input again
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine($"\nPlease do not leave it blank. Input up to 10 numbers.");
                return ElementByUser();
            }

            //Splitting the input string into an array of elements based on space
            string[] elements = userInput.Split(' ');

            //Prompt when the user inputted array elements is less than 2 (We cannot sort 1 number only)
            if (elements.Length < 2)
            {
                //Informing the user that at least 2 numbers are required and ask for input again
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine($"\nInvalid input. Please put at least 2 numbers to be sorted!");
                return ElementByUser();
            }

            //Prompt when the array elements exceeds 10
            if (elements.Length > 10)
            {
                // Informing the user that only up to 10 numbers are allowed and ask for input again
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine($"\nInvalid input. Please enter up to 10 numbers only!");
                return ElementByUser();
            }

            //Creating an array to store the parsed numbers
            int[] numbers = new int[elements.Length];

            //Iterating through the elements and parsing them to integers
            for (int i = 0; i < elements.Length; i++)
            {
                //Trying to parse the current element into an integer
                if (!int.TryParse(elements[i], out int number))
                {
                    // Informing the user about invalid input and asking for input again
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine($"\nInvalid input '{elements[i]}'. Please enter valid integers.");
                    return ElementByUser();
                }
                else
                {
                    //Storing the parsed number in the array
                    numbers[i] = number;
                }
            }

            //Returning the array of parsed numbers
            return numbers;
    }

    static int GetUserChoice(int minValue, int maxValue)
    {
        int choice;

        //Using a loop to repeatedly prompt the user until a valid choice is entered
        while (true)
        {
           //Prompting the user to choose a sorting algorithm
           Console.ForegroundColor = ConsoleColor.DarkCyan;
           Console.Write("\nChoose your desired sorting algorithm: ");
           Console.ForegroundColor = ConsoleColor.White;

           //Reading the user's input
           string pinili = Console.ReadLine();

           //Checking if the input is null or empty
           if (string.IsNullOrWhiteSpace(pinili))
           {
                //Informing the user not to leave the input blank and what numbers to be chosen
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine($"\nDo not leave this blank. Choose from {minValue} and {maxValue}");
                Console.ForegroundColor = ConsoleColor.White;
           }
           else if (int.TryParse(pinili, out choice) && choice >= minValue && choice <= maxValue)
           {
                //Parsing the input to an integer and checking if it's within the valid range
                return choice; //Returns the valid choice
           }
           else
           {
                //Informing the user about an invalid choice and what numbers to be chosen
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine($"\nInvalid choice '{pinili}'. Please enter a number between {minValue} and {maxValue}.");
                Console.ForegroundColor = ConsoleColor.White;
           }
        }
    }

    static void DisplayArray(int[] array)
    {
        //This displays the array 
        Console.WriteLine(string.Join(" ", array));
    }

    static int SortPass(int[] array, SortChoices algorithm)
    {
        // Create a copy of the original array to avoid modifying the original
        int[] tempArray = new int[array.Length];
        Array.Copy(array, tempArray, array.Length);

        int passes = 0; // Variable to store the number of passes made during sorting

        //Switch statement to choose the sorting algorithm based on the user's choice
        switch (algorithm)
        {
            //Calls the Sorting method chosen and get the number of passes
            case SortChoices.BubbleSort:
            passes = BubbleSort(tempArray);
            break;
            case SortChoices.SelectionSort:
            passes = SelectionSort(tempArray);
            break;
            case SortChoices.MergeSort:
            MergeSort(tempArray, 0, tempArray.Length - 1, ref passes);
            break;
            case SortChoices.InsertionSort:
            passes = InsertionSort(tempArray);
            break;
            case SortChoices.QuickSort:
            passes = QuickSort(tempArray);
            break;
            case SortChoices.HeapSort:
            passes = HeapSort(tempArray);
            break;
        }
            //Displays the sorted array after the chosen sorting algorithm is applied
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write($"\nSorted Array: ");
            Console.ForegroundColor = ConsoleColor.White;
            DisplayArray(tempArray);

            //Returns the total number of passes made during sorting
            return passes;
    }

    static int BubbleSort(int[] array)
    {
        /* Set the console color for initial array display and its elements(FORMALITY)
          This displays the initial array */
        Console.ForegroundColor = ConsoleColor.DarkMagenta;
        Console.Write($"Initial Array: ");
        Console.ForegroundColor = ConsoleColor.Gray;
        DisplayArray(array);
        Console.WriteLine("");
        Thread.Sleep(3000);

        //Get the length of the array
        int n = array.Length;

        //Variable to store the number of passes made during sorting
        int passes = 0;

        //Outer loop for each pass
        for (int i = 0; i < n - 1; i++)
        {
            //Variable to track whether any elements were swapped during this pass
            bool swapped = false;

            //Inner loop to iterate through the unsorted portion of the array
            for (int j = 0; j < n - i - 1; j++)
            {
                //Compare elements and swap if needed
                if (array[j] > array[j + 1])
                {
                    // Swap elements
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    swapped = true;

                    //Display the pass
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    if (passes == 0)
                    {
                            Console.Write($"{passes + 1}st Pass: ");
                            Console.ForegroundColor = ConsoleColor.White;
                            Thread.Sleep(1000);
                    }
                    else if (passes == 1)
                    {
                            Console.Write($"{passes + 1}nd Pass: ");
                            Console.ForegroundColor = ConsoleColor.White;
                            Thread.Sleep(1000);
                    }
                    else if (passes == 2)
                    {
                            Console.Write($"{passes + 1}rd Pass: ");
                            Console.ForegroundColor = ConsoleColor.White;
                            Thread.Sleep(1000);
                    }
                    else
                    {
                            Console.Write($"{passes + 1}th Pass: ");
                            Console.ForegroundColor = ConsoleColor.White;
                            Thread.Sleep(1000);
                    }
                   DisplayArray(array);
                }
            }
             //Increment passes only if a swap occurred during this pass
             if (swapped)
             {
                passes++;
             }
             else
             {
                // If no swaps occurred, the array is already sorted, and the sorting can be terminated
                break;
             }
        }
        //Return the total number of passes made during sorting
        return passes;
    }

    static int SelectionSort(int[] array)
    {
        /* Set the console color for initial array display and its elements(FORMALITY)
          This displays the initial array */
        Console.ForegroundColor = ConsoleColor.DarkMagenta;
        Console.Write($"Initial Array: ");
        Console.ForegroundColor = ConsoleColor.Gray;
        DisplayArray(array);
        Console.WriteLine("");
        Thread.Sleep(3000);

        //Get the length of the array
        int n = array.Length;

        //Variable to store the number of passes made during sorting
        int passes = 0;

        //Outer loop for each pass
        for (int i = 0; i < n - 1; i++)
        {
            //Variable to store the index of the minimum element in the unsorted portion
            int minIndex = i;

            //Inner loop to find the minimum element in the unsorted portion
            for (int j = i + 1; j < n; j++)
            {
                //Compare elements and update minIndex if a smaller element is found
                if (array[j] < array[minIndex])
                {
                    minIndex = j;
                }
            }

            //Swap elements to move the minimum element to its correct position
            int temp = array[minIndex];
            array[minIndex] = array[i];
            array[i] = temp;

            // Display the pass
            Console.ForegroundColor = ConsoleColor.Yellow;
            if (passes == 0)
            {
                Console.Write($"{passes + 1}st Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else if (passes == 1)
            {
                Console.Write($"{passes + 1}nd Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else if (passes == 2)
            {
                Console.Write($"{passes + 1}rd Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else
            {
                Console.Write($"{passes + 1}th Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
                DisplayArray(array);
                passes++;
        }
        //Return the total number of passes made during sorting
        return passes;
    }

    static void MergeSort(int[] array, int left, int right, ref int passes)
    {
        //Displays the initial array (if the if statement is not used, the initial array duplicates
        if (left == 0 && right == array.Length - 1)
        {
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.Write($"Initial Array: ");
                Console.ForegroundColor = ConsoleColor.Gray;
                DisplayArray(array);
                Console.WriteLine("");
                Thread.Sleep(3000);
        }

        //If the left index is less than the right index
        if (left < right)
        {
            //Calculates the middle index
            int middle = (left + right) / 2;

            //Calls Merge Sort in left and right arrays
            MergeSort(array, left, middle, ref passes);
            MergeSort(array, middle + 1, right, ref passes);

            //Merging th eboth splitted arrays
            Merge(array, left, middle, right);

            //Display the pass
            Console.ForegroundColor = ConsoleColor.Yellow;
            if (passes == 0)
            {
                Console.Write($"{passes + 1}st Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else if (passes == 1)
            {
                Console.Write($"{passes + 1}nd Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else if (passes == 2)
            {
                Console.Write($"{passes + 1}rd Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else
            {
                Console.Write($"{passes + 1}th Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            //Display the array after merging
                DisplayArray(array);
                passes++;
            }
        }

    static void Merge(int[] array, int left, int middle, int right)
    {
        //Calculate the sizes of the two subarrays to be merged
        int n1 = middle - left + 1;
        int n2 = right - middle;

        //Create temporary arrays to hold the values of the two subarrays
        int[] leftArray = new int[n1];
        int[] rightArray = new int[n2];

        //Copy data to temporary arrays
        Array.Copy(array, left, leftArray, 0, n1);
        Array.Copy(array, middle + 1, rightArray, 0, n2);

        //Merge the two subarrays back into the original array
        int i = 0, j = 0;
        int k = left;

        while (i < n1 && j < n2)
        {
            //Compare elements from the two subarrays and merge them in ascending order
            if (leftArray[i] <= rightArray[j])
            {
                array[k] = leftArray[i];
                i++;
            }
            else
            {
                array[k] = rightArray[j];
                j++;
            }
            k++;
        }
        
        //Copy the remaining elements of leftArray, if any
        while (i < n1)
        {
            array[k] = leftArray[i];
            i++;
            k++;
        }

        while (j < n2)
        {
            array[k] = rightArray[j];
            j++;
            k++;
        }
    }

    static int InsertionSort(int[] array)
    {
        /* Set the console color for initial array display and its elements(FORMALITY)
           This displays the initial array */
        Console.ForegroundColor = ConsoleColor.DarkMagenta;
        Console.Write($"Initial Array: ");
        Console.ForegroundColor = ConsoleColor.Gray;
        DisplayArray(array);
        Console.WriteLine("");
        Thread.Sleep(3000);

        //Get the length of the array
        int n = array.Length;

        //Variable to store the number of passes made during sorting
        int passes = 0;

        for (int i = 1; i < n; ++i)
        {
            int key = array[i];
            int j = i - 1;

            //Move elements of array[0..i-1] that are greater than key to one position ahead of their current position
            while (j >= 0 && array[j] > key)
            {
                array[j + 1] = array[j];
                j = j - 1;
            }

            //Place the key at its correct position in the sorted array
            array[j + 1] = key;

                //Displays the pass
                Console.ForegroundColor = ConsoleColor.Yellow;
                if (passes == 0)
                {
                    Console.Write($"{passes + 1}st Pass: ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Thread.Sleep(1000);
                }
                else if (passes == 1)
                {
                    Console.Write($"{passes + 1}nd Pass: ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Thread.Sleep(1000);
                }
                else if (passes == 2)
                {
                    Console.Write($"{passes + 1}rd Pass: ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Thread.Sleep(1000);
                }
                else
                {
                    Console.Write($"{passes + 1}th Pass: ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Thread.Sleep(1000);
                }
                //Display the array after each pass
                DisplayArray(array);
                passes++;
            }

        return passes;
    }

    static int QuickSort(int[] array)
    {
       /* Set the console color for initial array display and its elements(FORMALITY)
           This displays the initial array */
       Console.ForegroundColor = ConsoleColor.DarkMagenta;
       Console.Write($"Initial Array: ");
       Console.ForegroundColor = ConsoleColor.Gray;
       DisplayArray(array);
       Console.WriteLine("");
       Thread.Sleep(3000);
       
       //Variable to store the number of passes made during sorting
       int passes = 0;

       //Calls the SwapInQS method
       SwapInQS(array, 0, array.Length - 1, ref passes);
       return passes;
    }

    static void SwapInQS(int[] array, int low, int high, ref int passes)
    {
        if (low < high)
        {
          //partioning of the array
          int partitionIndex = PartitioninQS(array, low, high, ref passes);
          
          //Sort the sub-arrays
          SwapInQS(array, low, partitionIndex - 1, ref passes);
          SwapInQS(array, partitionIndex + 1, high, ref passes);
        }
    }

    static int PartitioninQS(int[] array, int low, int high, ref int passes)
    {
       int pivot = array[high];
       int i = low - 1;

          for (int j = low; j < high; j++)
          {
              if (array[j] < pivot)
              {
                   i++;

                   //Swap elements
                   int temp = array[i];
                   array[i] = array[j];
                   array[j] = temp;

                   //Display the pass
                   Console.ForegroundColor = ConsoleColor.Yellow;
                   if (passes == 0)
                   {
                       Console.Write($"{passes + 1}st Pass: ");
                       Console.ForegroundColor = ConsoleColor.White;
                       Thread.Sleep(1000);
                   }
                   else if (passes == 1)
                   {
                       Console.Write($"{passes + 1}nd Pass: ");
                       Console.ForegroundColor = ConsoleColor.White;
                       Thread.Sleep(1000);
                   }
                   else if (passes == 2)
                   {
                       Console.Write($"{passes + 1}rd Pass: ");
                       Console.ForegroundColor = ConsoleColor.White;
                       Thread.Sleep(1000);
                   }
                   else
                   {
                       Console.Write($"{passes + 1}th Pass: ");
                       Console.ForegroundColor = ConsoleColor.White;
                       Thread.Sleep(1000);
                   }
                    DisplayArray(array);
                    passes++;
                }
          }

            //Swap pivot with the element at i+1
            int tempPvt = array[i + 1];
            array[i + 1] = array[high];
            array[high] = tempPvt;

            //Display the pass
            Console.ForegroundColor = ConsoleColor.Yellow;
            if (passes == 0)
            {
                Console.Write($"{passes + 1}st Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else if (passes == 1)
            {
                Console.Write($"{passes + 1}nd Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else if (passes == 2)
            {
                Console.Write($"{passes + 1}rd Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else
            {
                Console.Write($"{passes + 1}th Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            DisplayArray(array);
            passes++;

            return i + 1;
    }

    static int HeapSort(int[] array)
    {
        /* Set the console color for initial array display and its elements(FORMALITY)
          This displays the initial array */
        Console.ForegroundColor = ConsoleColor.DarkMagenta;
        Console.Write($"Initial Array: ");
        Console.ForegroundColor = ConsoleColor.Gray;
        DisplayArray(array);
        Console.WriteLine("");
        Thread.Sleep(3000);

        //Variable to store the number of passes made during sorting
        int passes = 0;

        //Making a max heap
        for (int i = array.Length / 2 - 1; i >= 0; i--)
        {
            Heapify(array, array.Length, i, ref passes);
        }

        //Extracting elements in the heap
        for (int i = array.Length - 1; i > 0; i--)
        {
            //Swap root with the current element
            int temp = array[0];
            array[0] = array[i];
            array[i] = temp;

            //Display the pass
            Console.ForegroundColor = ConsoleColor.Yellow;
            if (passes == 0)
            {
                Console.Write($"{passes + 1}st Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else if (passes == 1)
            {
                Console.Write($"{passes + 1}nd Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else if (passes == 2)
            {
                Console.Write($"{passes + 1}rd Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else
            {
                Console.Write($"{passes + 1}th Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
           DisplayArray(array);
           passes++;
         
         //Rebuilding max heap
         Heapify(array, i, 0, ref passes);
        }
        return passes;
    }

    static void Heapify(int[] array, int n, int i, ref int passes)
    { 
            int largest = i;
            int left = 2 * i + 1;
            int right = 2 * i + 2;

        //Finding the largest element among root, left child, and right child
        if (left < n && array[left] > array[largest])
        {
            largest = left;
        }
        if (right < n && array[right] > array[largest])
        {
            largest = right;
        }
        if (largest != i)
        {
            //Swap elements
            int temp = array[i];
            array[i] = array[largest];
            array[largest] = temp;

            //Display the pass
            Console.ForegroundColor = ConsoleColor.Yellow;
            if (passes == 0)
            {
                Console.Write($"{passes + 1}st Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else if (passes == 1)
            {
                Console.Write($"{passes + 1}nd Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else if (passes == 2)
            {
                Console.Write($"{passes + 1}rd Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
            else 
            {
                Console.Write($"{passes + 1}th Pass: ");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
            }
                DisplayArray(array);
                passes++;
             //Recursively heapify the affected sub-tree
             Heapify(array, n, largest, ref passes);
        }
    }

    static bool AskUserToTryAgain()
    {
        while (true)
        {
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.Write("\nDo you want to try another sorting algorithm?\nEnter 'y' if yes or 'n' if no: ");
                Console.ForegroundColor = ConsoleColor.White;
                string select = Console.ReadLine().ToLower();
                if (select == "y")
                {
                    return true;
                }
                else if (select == "n")
                {
                    return false;
                }
                else if (select == "")
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine($"\nPlease do not leave it blank. Enter 'y' or 'n'");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine($"\nInvalid input '{select}'!. Please enter 'y' or 'n'.");
                }
            }
        }
    }
}