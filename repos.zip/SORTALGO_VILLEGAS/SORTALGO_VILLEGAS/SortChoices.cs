﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SORTALGO_VILLEGAS
{
    enum SortChoices
    {
        BubbleSort = 1,
        SelectionSort,
        MergeSort,
        InsertionSort,
        QuickSort,
        HeapSort
    }
}
