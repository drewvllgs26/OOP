namespace VILLEGAS_FINAL
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void registrationFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegistrationForm rgstrForm = new RegistrationForm();

            rgstrForm.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void goWithAQuizToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void calculatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Calculator clcltr = new Calculator();

            clcltr.Show();
        }
    }
}