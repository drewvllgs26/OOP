﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VILLEGAS_FINAL
{
    public partial class Calculator : Form
    {
        double rsltVal;
        string mathOperators = "";
        bool operationExecuted = false;

        public Calculator()
        {
            InitializeComponent();
        }

        private void num_Click(object sender, EventArgs e)
        {
            if ((calculate.Text == "0") || (operationExecuted))
                calculate.Clear();

            operationExecuted = false;
            Button btn = (Button)sender;
            calculate.Text = calculate.Text + btn.Text;
        }

        private void oprtn_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if (rsltVal != 0)
            {
                equalsButton.PerformClick();
                mathOperators = btn.Text;
                eqnLabel.Text = rsltVal + " " + mathOperators;
                operationExecuted = true;
            }
            else
            {
                mathOperators = btn.Text;
                rsltVal = Double.Parse(calculate.Text);
                eqnLabel.Text = rsltVal + " " + mathOperators;
                operationExecuted = true;
            }

        }
        private void decimalButton_Click(object sender, EventArgs e)
        {
            if (!calculate.Text.Contains("."))
            {
                calculate.Text += ".";
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            calculate.Text = "0";
            eqnLabel.Text = null;
            rsltVal = 0;
        }
        private void clearEntrybutton_Click(object sender, EventArgs e)
        {
            calculate.Text = "0";
        }
        private void negateButton_Click(object sender, EventArgs e)
        {
            if (calculate.Text.Contains("-"))
            {
                calculate.Text = calculate.Text.Trim('-');
            }
            else
            {
                calculate.Text = "-" + calculate.Text;
            }
        }

        private void equalsButton_Click(object sender, EventArgs e)
        {
            switch (mathOperators)
            {
                case "-":
                    calculate.Text = (rsltVal - Double.Parse(calculate.Text)).ToString();
                    break;
                case "+":
                    calculate.Text = (rsltVal + Double.Parse(calculate.Text)).ToString();
                    break;
                case "*":
                    calculate.Text = (rsltVal * Double.Parse(calculate.Text)).ToString();
                    break;
                case "/":
                    calculate.Text = (rsltVal / Double.Parse(calculate.Text)).ToString();
                    break;
                case "%":
                    calculate.Text = (rsltVal % Double.Parse(calculate.Text)).ToString();
                    break;
                default:
                    break;
            }
            rsltVal = Double.Parse(calculate.Text);
            eqnLabel.Text = "";
        }

        private void calculate_TextChanged(object sender, EventArgs e)
        {

        }


    }
}
