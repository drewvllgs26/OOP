﻿namespace VILLEGAS_FINAL
{
    partial class Main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            newToolStripMenuItem = new ToolStripMenuItem();
            openToolStripMenuItem = new ToolStripMenuItem();
            saveToolStripMenuItem = new ToolStripMenuItem();
            saveAsToolStripMenuItem = new ToolStripMenuItem();
            microsoftWorddocxToolStripMenuItem = new ToolStripMenuItem();
            pDFDocumentpdfToolStripMenuItem = new ToolStripMenuItem();
            plainTexttxtToolStripMenuItem = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            toolsToolStripMenuItem = new ToolStripMenuItem();
            optionsToolStripMenuItem = new ToolStripMenuItem();
            preferencesToolStripMenuItem = new ToolStripMenuItem();
            customizeToolStripMenuItem = new ToolStripMenuItem();
            addOnsToolStripMenuItem = new ToolStripMenuItem();
            registerToolStripMenuItem = new ToolStripMenuItem();
            registrationFormToolStripMenuItem = new ToolStripMenuItem();
            triviaToolStripMenuItem = new ToolStripMenuItem();
            goWithAQuizToolStripMenuItem = new ToolStripMenuItem();
            calculateToolStripMenuItem = new ToolStripMenuItem();
            calculatorToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = Color.MistyRose;
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, toolsToolStripMenuItem, registerToolStripMenuItem, triviaToolStripMenuItem, calculateToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(921, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { newToolStripMenuItem, openToolStripMenuItem, saveToolStripMenuItem, saveAsToolStripMenuItem, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            newToolStripMenuItem.Name = "newToolStripMenuItem";
            newToolStripMenuItem.Size = new Size(180, 22);
            newToolStripMenuItem.Text = "New";
            // 
            // openToolStripMenuItem
            // 
            openToolStripMenuItem.Name = "openToolStripMenuItem";
            openToolStripMenuItem.Size = new Size(180, 22);
            openToolStripMenuItem.Text = "Open";
            // 
            // saveToolStripMenuItem
            // 
            saveToolStripMenuItem.Image = Properties.Resources.icons8_save_48;
            saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            saveToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.S;
            saveToolStripMenuItem.Size = new Size(180, 22);
            saveToolStripMenuItem.Text = "Save";
            // 
            // saveAsToolStripMenuItem
            // 
            saveAsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { microsoftWorddocxToolStripMenuItem, pDFDocumentpdfToolStripMenuItem, plainTexttxtToolStripMenuItem });
            saveAsToolStripMenuItem.Image = Properties.Resources.icons8_save_all_48;
            saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            saveAsToolStripMenuItem.Size = new Size(180, 22);
            saveAsToolStripMenuItem.Text = "Save as";
            // 
            // microsoftWorddocxToolStripMenuItem
            // 
            microsoftWorddocxToolStripMenuItem.Name = "microsoftWorddocxToolStripMenuItem";
            microsoftWorddocxToolStripMenuItem.Size = new Size(197, 22);
            microsoftWorddocxToolStripMenuItem.Text = "Microsoft Word (.docx)";
            // 
            // pDFDocumentpdfToolStripMenuItem
            // 
            pDFDocumentpdfToolStripMenuItem.Name = "pDFDocumentpdfToolStripMenuItem";
            pDFDocumentpdfToolStripMenuItem.Size = new Size(197, 22);
            pDFDocumentpdfToolStripMenuItem.Text = "PDF Document (.pdf)";
            // 
            // plainTexttxtToolStripMenuItem
            // 
            plainTexttxtToolStripMenuItem.Name = "plainTexttxtToolStripMenuItem";
            plainTexttxtToolStripMenuItem.Size = new Size(197, 22);
            plainTexttxtToolStripMenuItem.Text = "Plain Text (.txt)";
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Image = Properties.Resources.icons8_shutdown_48;
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.W;
            exitToolStripMenuItem.Size = new Size(180, 22);
            exitToolStripMenuItem.Text = "Exit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // toolsToolStripMenuItem
            // 
            toolsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { optionsToolStripMenuItem, preferencesToolStripMenuItem, customizeToolStripMenuItem, addOnsToolStripMenuItem });
            toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            toolsToolStripMenuItem.Size = new Size(46, 20);
            toolsToolStripMenuItem.Text = "Tools";
            // 
            // optionsToolStripMenuItem
            // 
            optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            optionsToolStripMenuItem.Size = new Size(180, 22);
            optionsToolStripMenuItem.Text = "Options";
            // 
            // preferencesToolStripMenuItem
            // 
            preferencesToolStripMenuItem.Name = "preferencesToolStripMenuItem";
            preferencesToolStripMenuItem.Size = new Size(180, 22);
            preferencesToolStripMenuItem.Text = "Preferences";
            // 
            // customizeToolStripMenuItem
            // 
            customizeToolStripMenuItem.Name = "customizeToolStripMenuItem";
            customizeToolStripMenuItem.Size = new Size(180, 22);
            customizeToolStripMenuItem.Text = "Customize";
            // 
            // addOnsToolStripMenuItem
            // 
            addOnsToolStripMenuItem.Name = "addOnsToolStripMenuItem";
            addOnsToolStripMenuItem.Size = new Size(180, 22);
            addOnsToolStripMenuItem.Text = "Add-Ons";
            // 
            // registerToolStripMenuItem
            // 
            registerToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { registrationFormToolStripMenuItem });
            registerToolStripMenuItem.Name = "registerToolStripMenuItem";
            registerToolStripMenuItem.Size = new Size(61, 20);
            registerToolStripMenuItem.Text = "Register";
            // 
            // registrationFormToolStripMenuItem
            // 
            registrationFormToolStripMenuItem.Name = "registrationFormToolStripMenuItem";
            registrationFormToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.R;
            registrationFormToolStripMenuItem.Size = new Size(209, 22);
            registrationFormToolStripMenuItem.Text = "Registration Form";
            registrationFormToolStripMenuItem.Click += registrationFormToolStripMenuItem_Click;
            // 
            // triviaToolStripMenuItem
            // 
            triviaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { goWithAQuizToolStripMenuItem });
            triviaToolStripMenuItem.Name = "triviaToolStripMenuItem";
            triviaToolStripMenuItem.Size = new Size(46, 20);
            triviaToolStripMenuItem.Text = "Trivia";
            // 
            // goWithAQuizToolStripMenuItem
            // 
            goWithAQuizToolStripMenuItem.Name = "goWithAQuizToolStripMenuItem";
            goWithAQuizToolStripMenuItem.Size = new Size(161, 22);
            goWithAQuizToolStripMenuItem.Text = "Go-With-A-Quiz";
            goWithAQuizToolStripMenuItem.Click += goWithAQuizToolStripMenuItem_Click;
            // 
            // calculateToolStripMenuItem
            // 
            calculateToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { calculatorToolStripMenuItem });
            calculateToolStripMenuItem.Name = "calculateToolStripMenuItem";
            calculateToolStripMenuItem.Size = new Size(68, 20);
            calculateToolStripMenuItem.Text = "Calculate";
            // 
            // calculatorToolStripMenuItem
            // 
            calculatorToolStripMenuItem.Name = "calculatorToolStripMenuItem";
            calculatorToolStripMenuItem.ShortcutKeys = Keys.Alt | Keys.C;
            calculatorToolStripMenuItem.Size = new Size(180, 22);
            calculatorToolStripMenuItem.Text = "Calculator";
            calculatorToolStripMenuItem.Click += calculatorToolStripMenuItem_Click;
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(921, 522);
            Controls.Add(menuStrip1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MainMenuStrip = menuStrip1;
            MinimumSize = new Size(937, 561);
            Name = "Main";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Villegas Project";
            Load += Form1_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem newToolStripMenuItem;
        private ToolStripMenuItem openToolStripMenuItem;
        private ToolStripMenuItem saveToolStripMenuItem;
        private ToolStripMenuItem saveAsToolStripMenuItem;
        private ToolStripMenuItem microsoftWorddocxToolStripMenuItem;
        private ToolStripMenuItem pDFDocumentpdfToolStripMenuItem;
        private ToolStripMenuItem plainTexttxtToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem toolsToolStripMenuItem;
        private ToolStripMenuItem optionsToolStripMenuItem;
        private ToolStripMenuItem preferencesToolStripMenuItem;
        private ToolStripMenuItem customizeToolStripMenuItem;
        private ToolStripMenuItem addOnsToolStripMenuItem;
        private ToolStripMenuItem triviaToolStripMenuItem;
        private ToolStripMenuItem goWithAQuizToolStripMenuItem;
        private ToolStripMenuItem calculateToolStripMenuItem;
        private ToolStripMenuItem calculatorToolStripMenuItem;
        private ToolStripMenuItem registerToolStripMenuItem;
        private ToolStripMenuItem registrationFormToolStripMenuItem;
    }
}