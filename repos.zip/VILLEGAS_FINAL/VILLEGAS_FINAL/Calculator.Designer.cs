﻿namespace VILLEGAS_FINAL
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Calculator));
            ModuloButton = new Button();
            clearEntrybutton = new Button();
            n6 = new Button();
            multiplyButton = new Button();
            n5 = new Button();
            n4 = new Button();
            n3 = new Button();
            subtractButton = new Button();
            n2 = new Button();
            n1 = new Button();
            equalsButton = new Button();
            addButton = new Button();
            decimalButton = new Button();
            n0 = new Button();
            negateButton = new Button();
            n9 = new Button();
            n8 = new Button();
            n7 = new Button();
            divideButton = new Button();
            clearButton = new Button();
            eqnLabel = new Label();
            calculate = new TextBox();
            SuspendLayout();
            // 
            // ModuloButton
            // 
            ModuloButton.BackColor = SystemColors.AppWorkspace;
            ModuloButton.FlatStyle = FlatStyle.Flat;
            ModuloButton.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            ModuloButton.Location = new Point(12, 130);
            ModuloButton.Name = "ModuloButton";
            ModuloButton.Size = new Size(75, 74);
            ModuloButton.TabIndex = 4;
            ModuloButton.Text = "%";
            ModuloButton.UseVisualStyleBackColor = false;
            ModuloButton.Click += oprtn_Click;
            // 
            // clearEntrybutton
            // 
            clearEntrybutton.BackColor = SystemColors.AppWorkspace;
            clearEntrybutton.FlatStyle = FlatStyle.Flat;
            clearEntrybutton.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            clearEntrybutton.Location = new Point(255, 130);
            clearEntrybutton.Name = "clearEntrybutton";
            clearEntrybutton.Size = new Size(75, 74);
            clearEntrybutton.TabIndex = 3;
            clearEntrybutton.Text = "CE";
            clearEntrybutton.UseVisualStyleBackColor = false;
            clearEntrybutton.Click += clearEntrybutton_Click;
            // 
            // n6
            // 
            n6.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            n6.Location = new Point(174, 290);
            n6.Name = "n6";
            n6.Size = new Size(75, 74);
            n6.TabIndex = 8;
            n6.Text = "6";
            n6.UseVisualStyleBackColor = true;
            n6.Click += num_Click;
            // 
            // multiplyButton
            // 
            multiplyButton.BackColor = SystemColors.AppWorkspace;
            multiplyButton.FlatStyle = FlatStyle.Flat;
            multiplyButton.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            multiplyButton.Location = new Point(255, 290);
            multiplyButton.Name = "multiplyButton";
            multiplyButton.Size = new Size(75, 74);
            multiplyButton.TabIndex = 7;
            multiplyButton.Text = "*";
            multiplyButton.UseVisualStyleBackColor = false;
            multiplyButton.Click += oprtn_Click;
            // 
            // n5
            // 
            n5.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            n5.Location = new Point(93, 290);
            n5.Name = "n5";
            n5.Size = new Size(75, 74);
            n5.TabIndex = 6;
            n5.Text = "5";
            n5.UseVisualStyleBackColor = true;
            n5.Click += num_Click;
            // 
            // n4
            // 
            n4.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            n4.Location = new Point(12, 290);
            n4.Name = "n4";
            n4.Size = new Size(75, 74);
            n4.TabIndex = 5;
            n4.Text = "4";
            n4.UseVisualStyleBackColor = true;
            n4.Click += num_Click;
            // 
            // n3
            // 
            n3.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            n3.Location = new Point(174, 370);
            n3.Name = "n3";
            n3.Size = new Size(75, 74);
            n3.TabIndex = 12;
            n3.Text = "3";
            n3.UseVisualStyleBackColor = true;
            n3.Click += num_Click;
            // 
            // subtractButton
            // 
            subtractButton.BackColor = SystemColors.AppWorkspace;
            subtractButton.FlatStyle = FlatStyle.Flat;
            subtractButton.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            subtractButton.Location = new Point(255, 450);
            subtractButton.Name = "subtractButton";
            subtractButton.Size = new Size(75, 74);
            subtractButton.TabIndex = 11;
            subtractButton.Text = "-";
            subtractButton.UseVisualStyleBackColor = false;
            subtractButton.Click += oprtn_Click;
            // 
            // n2
            // 
            n2.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            n2.Location = new Point(93, 370);
            n2.Name = "n2";
            n2.Size = new Size(75, 74);
            n2.TabIndex = 10;
            n2.Text = "2";
            n2.UseVisualStyleBackColor = true;
            n2.Click += num_Click;
            // 
            // n1
            // 
            n1.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            n1.Location = new Point(12, 370);
            n1.Name = "n1";
            n1.Size = new Size(75, 74);
            n1.TabIndex = 9;
            n1.Text = "1";
            n1.UseVisualStyleBackColor = true;
            n1.Click += num_Click;
            // 
            // equalsButton
            // 
            equalsButton.BackColor = Color.LightCoral;
            equalsButton.FlatStyle = FlatStyle.Flat;
            equalsButton.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            equalsButton.Location = new Point(174, 450);
            equalsButton.Name = "equalsButton";
            equalsButton.Size = new Size(75, 74);
            equalsButton.TabIndex = 16;
            equalsButton.Text = "=";
            equalsButton.UseVisualStyleBackColor = false;
            equalsButton.Click += equalsButton_Click;
            // 
            // addButton
            // 
            addButton.BackColor = SystemColors.AppWorkspace;
            addButton.FlatStyle = FlatStyle.Flat;
            addButton.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            addButton.Location = new Point(255, 370);
            addButton.Name = "addButton";
            addButton.Size = new Size(75, 74);
            addButton.TabIndex = 15;
            addButton.Text = "+";
            addButton.UseVisualStyleBackColor = false;
            addButton.Click += oprtn_Click;
            // 
            // decimalButton
            // 
            decimalButton.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            decimalButton.Location = new Point(93, 450);
            decimalButton.Name = "decimalButton";
            decimalButton.Size = new Size(75, 74);
            decimalButton.TabIndex = 14;
            decimalButton.Text = ".";
            decimalButton.UseVisualStyleBackColor = true;
            decimalButton.Click += decimalButton_Click;
            // 
            // n0
            // 
            n0.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            n0.Location = new Point(12, 450);
            n0.Name = "n0";
            n0.Size = new Size(75, 74);
            n0.TabIndex = 13;
            n0.Text = "0";
            n0.UseVisualStyleBackColor = true;
            n0.Click += num_Click;
            // 
            // negateButton
            // 
            negateButton.BackColor = SystemColors.AppWorkspace;
            negateButton.FlatStyle = FlatStyle.Flat;
            negateButton.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            negateButton.Location = new Point(93, 130);
            negateButton.Name = "negateButton";
            negateButton.Size = new Size(75, 74);
            negateButton.TabIndex = 17;
            negateButton.Text = "+/−";
            negateButton.UseVisualStyleBackColor = false;
            negateButton.Click += negateButton_Click;
            // 
            // n9
            // 
            n9.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            n9.Location = new Point(174, 210);
            n9.Name = "n9";
            n9.Size = new Size(75, 74);
            n9.TabIndex = 20;
            n9.Text = "9";
            n9.UseVisualStyleBackColor = true;
            n9.Click += num_Click;
            // 
            // n8
            // 
            n8.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            n8.Location = new Point(93, 210);
            n8.Name = "n8";
            n8.Size = new Size(75, 74);
            n8.TabIndex = 19;
            n8.Text = "8";
            n8.UseVisualStyleBackColor = true;
            n8.Click += num_Click;
            // 
            // n7
            // 
            n7.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            n7.Location = new Point(12, 210);
            n7.Name = "n7";
            n7.Size = new Size(75, 74);
            n7.TabIndex = 18;
            n7.Text = "7";
            n7.UseVisualStyleBackColor = true;
            n7.Click += num_Click;
            // 
            // divideButton
            // 
            divideButton.BackColor = SystemColors.AppWorkspace;
            divideButton.FlatStyle = FlatStyle.Flat;
            divideButton.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            divideButton.Location = new Point(255, 210);
            divideButton.Name = "divideButton";
            divideButton.Size = new Size(75, 74);
            divideButton.TabIndex = 21;
            divideButton.Text = "/";
            divideButton.UseVisualStyleBackColor = false;
            divideButton.Click += oprtn_Click;
            // 
            // clearButton
            // 
            clearButton.BackColor = SystemColors.AppWorkspace;
            clearButton.FlatStyle = FlatStyle.Flat;
            clearButton.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            clearButton.Location = new Point(174, 130);
            clearButton.Name = "clearButton";
            clearButton.Size = new Size(75, 74);
            clearButton.TabIndex = 22;
            clearButton.Text = "C";
            clearButton.UseVisualStyleBackColor = false;
            clearButton.Click += clearButton_Click;
            // 
            // eqnLabel
            // 
            eqnLabel.AutoSize = true;
            eqnLabel.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            eqnLabel.ForeColor = Color.DarkGray;
            eqnLabel.Location = new Point(16, 21);
            eqnLabel.Name = "eqnLabel";
            eqnLabel.Size = new Size(0, 20);
            eqnLabel.TabIndex = 23;
            // 
            // calculate
            // 
            calculate.BackColor = Color.White;
            calculate.Font = new Font("Microsoft Sans Serif", 27.75F, FontStyle.Bold, GraphicsUnit.Point);
            calculate.Location = new Point(12, 45);
            calculate.Name = "calculate";
            calculate.ReadOnly = true;
            calculate.Size = new Size(318, 49);
            calculate.TabIndex = 24;
            calculate.Text = "0";
            calculate.TextAlign = HorizontalAlignment.Right;
            // 
            // Calculator
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gainsboro;
            ClientSize = new Size(345, 540);
            Controls.Add(calculate);
            Controls.Add(eqnLabel);
            Controls.Add(clearButton);
            Controls.Add(divideButton);
            Controls.Add(n9);
            Controls.Add(n8);
            Controls.Add(n7);
            Controls.Add(negateButton);
            Controls.Add(equalsButton);
            Controls.Add(addButton);
            Controls.Add(decimalButton);
            Controls.Add(n0);
            Controls.Add(n3);
            Controls.Add(subtractButton);
            Controls.Add(n2);
            Controls.Add(n1);
            Controls.Add(n6);
            Controls.Add(multiplyButton);
            Controls.Add(n5);
            Controls.Add(n4);
            Controls.Add(ModuloButton);
            Controls.Add(clearEntrybutton);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MinimumSize = new Size(360, 553);
            Name = "Calculator";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button ModuloButton;
        private Button clearEntrybutton;
        private Button n6;
        private Button multiplyButton;
        private Button n5;
        private Button n4;
        private Button n3;
        private Button subtractButton;
        private Button n2;
        private Button n1;
        private Button equalsButton;
        private Button addButton;
        private Button decimalButton;
        private Button n0;
        private Button negateButton;
        private Button n9;
        private Button n8;
        private Button n7;
        private Button divideButton;
        private Button clearButton;
        private Label eqnLabel;
        private TextBox calculate;
    }
}