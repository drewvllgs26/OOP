﻿namespace VILLEGAS_FINAL
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            rgstrnFrmLabel = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.LightCoral;
            panel1.BackgroundImageLayout = ImageLayout.None;
            panel1.Controls.Add(rgstrnFrmLabel);
            panel1.Location = new Point(-36, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(830, 71);
            panel1.TabIndex = 0;
            // 
            // rgstrnFrmLabel
            // 
            rgstrnFrmLabel.AutoSize = true;
            rgstrnFrmLabel.Font = new Font("Franklin Gothic Medium Cond", 26.25F, FontStyle.Regular, GraphicsUnit.Point);
            rgstrnFrmLabel.Location = new Point(57, 10);
            rgstrnFrmLabel.Name = "rgstrnFrmLabel";
            rgstrnFrmLabel.Size = new Size(248, 41);
            rgstrnFrmLabel.TabIndex = 1;
            rgstrnFrmLabel.Text = "Registration Form";
            // 
            // RegistrationForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            ClientSize = new Size(756, 935);
            Controls.Add(panel1);
            Name = "RegistrationForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "RegistrationForm";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label rgstrnFrmLabel;
    }
}